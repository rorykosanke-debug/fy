plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.rorykosanke.fanyifloat"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.rorykosanke.fanyifloat"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // 端侧文字识别（模型打包进 APK，不依赖 Google 服务，离线可用）
    implementation("com.google.mlkit:text-recognition:16.0.0")
    implementation("com.google.mlkit:text-recognition-chinese:16.0.0")
    // 网络请求（调用 DeepSeek）
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
}
