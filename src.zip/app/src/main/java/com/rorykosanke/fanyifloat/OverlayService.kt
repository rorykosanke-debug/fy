package com.rorykosanke.fanyifloat

import android.app.Activity
import android.app.Notification
import android.content.ClipData
import android.content.ClipboardManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors
import kotlin.math.abs

/**
 * 悬浮翻译服务：
 *  - 一个可拖动/可缩放的「选区框」盖在视频上
 *  - 一个可拖动的按钮列（译 / 设 / 关）
 *  - 点「译」→ 截取选区 → OCR → 调 DeepSeek 翻译 → 显示在框下方
 */
class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private val mainHandler = Handler(Looper.getMainLooper())
    private val captureExec = Executors.newSingleThreadExecutor()

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private var screenW = 0
    private var screenH = 0
    private var screenDensity = 0

    private var selectionView: FrameLayout? = null
    private var selParams: WindowManager.LayoutParams? = null
    private var controlView: LinearLayout? = null
    private var resultView: LinearLayout? = null
    private val lineViews = ArrayList<View>()
    private var selHandle: View? = null
    private var selBg: android.graphics.drawable.Drawable? = null
    private var bodyRef: LinearLayout? = null
    private var toggleRef: TextView? = null
    private var controlParams: WindowManager.LayoutParams? = null
    private var docked = 0
    private var resultAlpha = 1f
    private var fullScreen = false
    private var frameHidden = false
    private var resultMoved = false

    private var busy = false

    private var autoMode = false
    private var lastSig: FloatArray? = null
    private var lastUtterance: String? = null
    private val recentKeys = ArrayList<String>()
    private val autoRunnable = Runnable { autoTick() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || intent.getStringExtra("action") == "stop") {
            stopSelf()
            return START_NOT_STICKY
        }

        // 1) 必须先进入前台（Android 14 要求 mediaProjection 前台服务早于使用投屏）
        startForegroundInternal()

        val code = intent.getIntExtra("code", Activity.RESULT_CANCELED)
        @Suppress("DEPRECATION")
        val data = intent.getParcelableExtra<Intent>("data")
        if (code != Activity.RESULT_OK || data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        if (projection == null) {
            try {
                setupProjection(code, data)
            } catch (e: Exception) {
                e.printStackTrace()
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    // ---------------- 前台通知 ----------------
    private fun startForegroundInternal() {
        val channelId = "fanyi_channel"
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(channelId, "悬浮翻译", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val notification: Notification = Notification.Builder(this, channelId)
            .setContentTitle("悬浮翻译运行中")
            .setContentText("点悬浮按钮「译」翻译选区文字")
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIF_ID, notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    // ---------------- 投屏 + 截屏 ----------------
    private fun setupProjection(code: Int, data: Intent) {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)

        val size = realScreenSize()
        screenW = size[0]
        screenH = size[1]
        screenDensity = resources.displayMetrics.densityDpi

        imageReader = ImageReader.newInstance(screenW, screenH, PixelFormat.RGBA_8888, 2)

        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopSelf()
            }
        }, mainHandler)

        virtualDisplay = projection?.createVirtualDisplay(
            "fanyi_cap",
            screenW, screenH, screenDensity,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, mainHandler
        )

        buildOverlays()
    }

    private fun realScreenSize(): IntArray {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val b = wm.maximumWindowMetrics.bounds
            intArrayOf(b.width(), b.height())
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(dm)
            intArrayOf(dm.widthPixels, dm.heightPixels)
        }
    }

    // ---------------- 悬浮 UI ----------------
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun buildOverlays() {
        buildSelection()
        buildResult()
        buildControl()
    }

    private fun buildSelection() {
        val sel = FrameLayout(this)
        sel.background = GradientDrawable().apply {
            setColor(0x1A22C55E)
            setStroke(dp(2), 0xFF22C55E.toInt())
            cornerRadius = dp(6).toFloat()
        }
        selBg = sel.background

        // 右下角缩放把手
        val handle = View(this)
        val hp = FrameLayout.LayoutParams(dp(26), dp(26), Gravity.END or Gravity.BOTTOM)
        handle.layoutParams = hp
        handle.background = GradientDrawable().apply {
            setColor(0xFF22C55E.toInt())
            cornerRadius = dp(6).toFloat()
        }
        sel.addView(handle)
        selHandle = handle

        // 恢复上次的框位置/大小；没有则用默认
        val saved = Prefs.getSelBounds(this)
        var sw = (screenW * 0.82).toInt()
        var sh = (screenH * 0.14).toInt()
        var sx = (screenW * 0.09).toInt()
        var sy = (screenH * 0.62).toInt()
        if (saved != null) {
            sw = saved[2].coerceIn(dp(120), screenW)
            sh = saved[3].coerceIn(dp(50), screenH)
            sx = saved[0].coerceIn(0, (screenW - sw).coerceAtLeast(0))
            sy = saved[1].coerceIn(0, (screenH - sh).coerceAtLeast(0))
        }
        val sp = WindowManager.LayoutParams(
            sw, sh,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        sp.gravity = Gravity.TOP or Gravity.START
        sp.x = sx
        sp.y = sy
        selParams = sp

        sel.setOnTouchListener(object : View.OnTouchListener {
            var startRawX = 0
            var startRawY = 0
            var startW = 0
            var startH = 0
            var startX = 0
            var startY = 0
            var resizing = false

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        startRawX = e.rawX.toInt()
                        startRawY = e.rawY.toInt()
                        startW = sp.width
                        startH = sp.height
                        startX = sp.x
                        startY = sp.y
                        resizing = e.x > sp.width - dp(42) && e.y > sp.height - dp(42)
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX.toInt() - startRawX
                        val dy = e.rawY.toInt() - startRawY
                        if (resizing) {
                            sp.width = (startW + dx).coerceAtLeast(dp(120))
                            sp.height = (startH + dy).coerceAtLeast(dp(50))
                        } else {
                            sp.x = startX + dx
                            sp.y = startY + dy
                        }
                        safeUpdate(sel, sp)
                        positionResult()
                        return true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        Prefs.saveSelBounds(this@OverlayService, sp.x, sp.y, sp.width, sp.height)
                        return true
                    }
                }
                return false
            }
        })

        try {
            wm.addView(sel, sp)
            selectionView = sel
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun buildResult() {
        val rv = LinearLayout(this)
        rv.orientation = LinearLayout.VERTICAL
        rv.setPadding(dp(10), dp(8), dp(10), dp(8))
        rv.background = GradientDrawable().apply {
            setColor(0xCC000000.toInt())
            cornerRadius = dp(8).toFloat()
        }
        val rp = WindowManager.LayoutParams(
            dp(220), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        rp.gravity = Gravity.TOP or Gravity.START
        rp.x = dp(10)
        rp.y = dp(10)
        // 顶部拖动条：按住可移动整个译文框
        val grip = TextView(this)
        grip.text = "⠿ 拖动"
        grip.setTextColor(0xFF8EA1BD.toInt())
        grip.textSize = 11f
        grip.setPadding(dp(2), 0, dp(2), dp(2))
        grip.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var px = 0; var py = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                val lp = rv.layoutParams as? WindowManager.LayoutParams ?: return false
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = e.rawX.toInt(); sy = e.rawY.toInt(); px = lp.x; py = lp.y; return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        lp.x = px + (e.rawX.toInt() - sx)
                        lp.y = py + (e.rawY.toInt() - sy)
                        resultMoved = true
                        safeUpdate(rv, lp)
                        return true
                    }
                }
                return false
            }
        })
        rv.addView(grip)
        try {
            wm.addView(rv, rp)
            resultView = rv
            rv.alpha = resultAlpha
            rv.visibility = View.GONE
            positionResult()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun pushTranslation(original: String, translation: String) {
        mainHandler.post {
            RecordStore.add(this, original, translation)
            val container = resultView ?: return@post
            container.visibility = View.VISIBLE
            val dual = Prefs.getDisplay(this) == "double"
            val orig = original.trim()
            if (dual && orig.isNotBlank() && orig != translation.trim()) {
                addLine(container, orig, 0xFF9FB0C7.toInt(), 12f, true)   // 原文可关
            }
            addLine(container, translation.trim(), 0xFFFFFFFF.toInt(), 15f, false) // 译文保留
            while (lineViews.size > 3) {
                val oldest = lineViews.removeAt(0)
                oldest.animate().alpha(0f).setDuration(450).withEndAction { container.removeView(oldest) }.start()
            }
            positionResult()
        }
    }

    private fun addLine(container: LinearLayout, text: String, color: Int, sizeSp: Float, closable: Boolean) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)

        val tv = TextView(this)
        tv.text = text
        tv.setTextColor(color)
        tv.textSize = sizeSp
        tv.setPadding(dp(2), dp(1), dp(2), dp(1))
        tv.setTextIsSelectable(true)
        tv.isClickable = true
        tv.isLongClickable = true
        tv.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        tv.setOnClickListener {
            try {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("翻译", tv.text))
                Toast.makeText(this, "已复制这一行", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
            }
        }
        row.addView(tv)

        if (closable) {
            val close = TextView(this)
            close.text = "✕"
            close.setTextColor(0xFF94A3B8.toInt())
            close.textSize = 13f
            close.setPadding(dp(6), dp(1), dp(2), dp(1))
            close.isClickable = true
            close.setOnClickListener {
                container.removeView(row)
                lineViews.remove(row)
                positionResult()
            }
            row.addView(close)
        }

        row.alpha = 0f
        container.addView(row)
        lineViews.add(row)
        row.animate().alpha(1f).setDuration(200).start()
    }

    private fun buildControl() {
        val cv = LinearLayout(this)
        cv.orientation = LinearLayout.VERTICAL
        cv.setPadding(dp(4), dp(4), dp(4), dp(4))
        cv.background = GradientDrawable().apply {
            setColor(0xE6111827.toInt())
            cornerRadius = dp(16).toFloat()
        }

        val cp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        cp.gravity = Gravity.TOP or Gravity.START
        cp.x = dp(8)
        cp.y = dp(140)
        controlParams = cp
        docked = 0

        val body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        bodyRef = body

        // 折叠 / 展开
        val toggle = circleBtn("−", 0xFF243247.toInt(), 0xFFFFFFFF.toInt())
        toggleRef = toggle
        toggle.setOnClickListener {
            if (body.visibility == View.VISIBLE) collapsePanel() else expandPanel()
        }
        cv.addView(toggle)

        // 拖动把手：拖到左/右边缘自动贴边收起成细条
        val handle = TextView(this)
        handle.text = "⋮"
        handle.setTextColor(0xFF8EA1BD.toInt())
        handle.textSize = 14f
        handle.gravity = Gravity.CENTER
        handle.layoutParams = LinearLayout.LayoutParams(dp(48), dp(20))
        handle.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var px = 0; var py = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = e.rawX.toInt(); sy = e.rawY.toInt(); px = cp.x; py = cp.y; return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        cp.x = px + (e.rawX.toInt() - sx)
                        cp.y = py + (e.rawY.toInt() - sy)
                        safeUpdate(cv, cp)
                        return true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        dockIfNearEdge(cv, cp)
                        return true
                    }
                }
                return false
            }
        })
        body.addView(handle)

        val bAuto = circleBtn("手动", 0xFF0EA5E9.toInt(), 0xFFFFFFFF.toInt())
        bAuto.textSize = 13f
        val bTrans = circleBtn("译", 0xFF22C55E.toInt(), 0xFF06140A.toInt())

        // 全屏翻译开关
        val bFull = circleBtn("全", 0xFF111827.toInt(), 0xFFFFFFFF.toInt())
        bFull.setOnClickListener {
            fullScreen = !fullScreen
            bFull.background = GradientDrawable().apply {
                setColor(if (fullScreen) 0xFF16A34A.toInt() else 0xFF111827.toInt())
                shape = GradientDrawable.OVAL
            }
            Toast.makeText(this, if (fullScreen) "全屏翻译：翻整个屏幕" else "选区翻译：只翻绿框内", Toast.LENGTH_SHORT).show()
        }

        // 显示/隐藏 绿色读取框
        val bFrame = circleBtn("框", 0xFF111827.toInt(), 0xFFFFFFFF.toInt())
        bFrame.setOnClickListener {
            frameHidden = !frameHidden
            selectionView?.visibility = if (frameHidden) View.GONE else View.VISIBLE
            if (!frameHidden) restoreSelectionChrome()
            bFrame.background = GradientDrawable().apply {
                setColor(if (frameHidden) 0xFF16A34A.toInt() else 0xFF111827.toInt())
                shape = GradientDrawable.OVAL
            }
            Toast.makeText(this, if (frameHidden) "已隐藏绿色读取框" else "已显示绿色读取框", Toast.LENGTH_SHORT).show()
        }

        val bSet = circleBtn("设", 0xFF243247.toInt(), 0xFFFFFFFF.toInt())
        val bClose = circleBtn("✕", 0xFFB91C1C.toInt(), 0xFFFFFFFF.toInt())

        bAuto.setOnClickListener { if (autoMode) stopAuto(bAuto) else startAuto(bAuto) }
        bTrans.setOnClickListener { captureAndTranslate() }
        bSet.setOnClickListener {
            expandPanel()
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        bClose.setOnClickListener { stopSelf() }

        body.addView(bAuto)
        body.addView(bTrans)
        body.addView(bFull)
        body.addView(bFrame)
        body.addView(bSet)
        body.addView(bClose)
        cv.addView(body)

        try {
            wm.addView(cv, cp)
            controlView = cv
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun dualShort(): String = if (Prefs.getDisplay(this) == "double") "双" else "单"

    private fun cycleResultAlpha() {
        resultAlpha = when {
            resultAlpha >= 0.99f -> 0.6f
            resultAlpha >= 0.59f -> 0.3f
            else -> 1f
        }
        applyResultAlpha()
    }

    private fun resultAlphaText(): String = when {
        resultAlpha >= 0.99f -> "不透明"
        resultAlpha >= 0.59f -> "半透明"
        else -> "很淡"
    }

    private fun applyResultAlpha() {
        mainHandler.post { resultView?.alpha = resultAlpha }
    }

    private fun collapsePanel() {
        bodyRef?.visibility = View.GONE
        val cp = controlParams ?: return
        val toggle = toggleRef ?: return
        if (docked != 0) {
            // 贴边：收成很窄的一条边 + 一个 > / <
            val thinW = dp(16)
            val thinH = dp(72)
            toggle.layoutParams = LinearLayout.LayoutParams(thinW, thinH)
            toggle.textSize = 18f
            toggle.text = if (docked == -1) ">" else "<"
            toggle.background = GradientDrawable().apply {
                setColor(0xE6111827.toInt())
                cornerRadius = dp(6).toFloat()
            }
            cp.x = if (docked == -1) 0 else screenW - thinW
            safeUpdate(controlView, cp)
        } else {
            toggle.text = "≡"
        }
    }

    private fun expandPanel() {
        bodyRef?.visibility = View.VISIBLE
        val cp = controlParams ?: return
        val toggle = toggleRef ?: return
        toggle.layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
        toggle.textSize = 16f
        toggle.text = "−"
        toggle.background = GradientDrawable().apply {
            setColor(0xFF243247.toInt())
            shape = GradientDrawable.OVAL
        }
        if (docked == 1) {
            cp.x = screenW - panelWidth() - dp(6)
            safeUpdate(controlView, cp)
            docked = 0
        } else if (docked == -1) {
            cp.x = dp(6)
            safeUpdate(controlView, cp)
            docked = 0
        } else {
            safeUpdate(controlView, cp)
        }
    }

    private fun panelWidth(): Int {
        val w = controlView?.width ?: 0
        return if (w > 0) w else dp(56)
    }

    private fun dockIfNearEdge(cv: LinearLayout, cp: WindowManager.LayoutParams) {
        val w = if (cv.width > 0) cv.width else dp(56)
        val threshold = dp(48)
        if (cp.x <= threshold) {
            cp.x = 0
            docked = -1
            safeUpdate(cv, cp)
            collapsePanel()
        } else if (cp.x + w >= screenW - threshold) {
            cp.x = screenW - w
            docked = 1
            safeUpdate(cv, cp)
            collapsePanel()
        } else {
            docked = 0
            safeUpdate(cv, cp)
        }
    }

    private fun circleBtn(text: String, bg: Int, fg: Int): TextView {
        val tv = TextView(this)
        tv.text = text
        tv.setTextColor(fg)
        tv.textSize = 16f
        tv.gravity = Gravity.CENTER
        val lp = LinearLayout.LayoutParams(dp(48), dp(48))
        lp.topMargin = dp(4)
        lp.bottomMargin = dp(4)
        tv.layoutParams = lp
        tv.background = GradientDrawable().apply {
            setColor(bg)
            shape = GradientDrawable.OVAL
        }
        tv.isClickable = true
        return tv
    }

    private fun positionResult() {
        val sp = selParams ?: return
        val rv = resultView ?: return
        val p = rv.layoutParams as? WindowManager.LayoutParams ?: return
        p.width = sp.width
        if (!resultMoved) {
            p.x = sp.x
            p.y = sp.y + sp.height + dp(6)
        }
        safeUpdate(rv, p)
    }

    private fun resultOverlapsSelection(sp: WindowManager.LayoutParams): Boolean {
        val rv = resultView ?: return false
        if (rv.visibility != View.VISIBLE) return false
        val p = rv.layoutParams as? WindowManager.LayoutParams ?: return false
        val rh = if (rv.height > 0) rv.height else dp(60)
        val rw = if (p.width > 0) p.width else rv.width
        val overlapX = p.x < sp.x + sp.width && p.x + rw > sp.x
        val overlapY = p.y < sp.y + sp.height && p.y + rh > sp.y
        return overlapX && overlapY
    }

    private fun safeUpdate(view: View?, params: WindowManager.LayoutParams) {
        if (view == null) return
        try {
            wm.updateViewLayout(view, params)
        } catch (e: Exception) {
            // 视图可能已被移除，忽略
        }
    }

    // ---------------- 截图 → OCR → 翻译 ----------------
    private fun captureAndTranslate() {
        if (busy) return
        val sp = selParams ?: return
        if (imageReader == null) {
            setResult("❗ 投屏未就绪，请关闭后重新开始")
            return
        }
        busy = true
        hideSelectionChrome()
        val needHide = fullScreen || resultOverlapsSelection(sp)
        val resultWasVisible = resultView?.visibility == View.VISIBLE
        if (needHide) mainHandler.post { resultView?.visibility = View.GONE }
        mainHandler.postDelayed({
            captureExec.execute {
                try {
                    val crop = cropRegion(sp)
                    if (needHide) mainHandler.post { if (resultWasVisible) resultView?.visibility = View.VISIBLE }
                    if (crop == null) {
                        setResult("❗ 截取画面失败，请重试")
                        busy = false
                        return@execute
                    }
                    Ocr.recognize(crop) { text ->
                        if (text.isBlank()) {
                            setResult("（选区里没识别到文字，挪一下框再试）")
                            busy = false
                        } else {
                            Translator.translate(this, text) { translated ->
                                pushTranslation(text, translated)
                                busy = false
                            }
                        }
                    }
                } catch (e: Exception) {
                    setResult("❗ 出错：" + (e.message ?: ""))
                    busy = false
                } finally {
                    mainHandler.post {
                        restoreSelectionChrome()
                        if (needHide) resultView?.visibility = View.VISIBLE
                    }
                }
            }
        }, 160)
    }

    private fun cropRegion(sp: WindowManager.LayoutParams): Bitmap? {
        val full = grabLatestBitmap() ?: return null
        if (fullScreen) return scaleDown(full)
        val cx = sp.x.coerceIn(0, full.width - 1)
        val cy = sp.y.coerceIn(0, full.height - 1)
        val cw = sp.width.coerceAtMost(full.width - cx).coerceAtLeast(1)
        val ch = sp.height.coerceAtMost(full.height - cy).coerceAtLeast(1)
        return Bitmap.createBitmap(full, cx, cy, cw, ch)
    }

    private fun scaleDown(bmp: Bitmap): Bitmap {
        val maxW = 1280
        if (bmp.width <= maxW) return bmp
        val ratio = maxW.toFloat() / bmp.width
        val h = (bmp.height * ratio).toInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(bmp, maxW, h, true)
    }

    private fun startAuto(btn: TextView) {
        if (imageReader == null) {
            setResult("❗ 投屏未就绪，请关闭后重新开始")
            return
        }
        autoMode = true
        lastSig = null
        lastUtterance = null
        hideSelectionChrome()
        btn.text = "自动"
        btn.background = GradientDrawable().apply {
            setColor(0xFFDC2626.toInt())
            shape = GradientDrawable.OVAL
        }
        setResult("自动翻译中… 画面文字一变化就自动翻译")
        scheduleAuto()
    }

    private fun stopAuto(btn: TextView) {
        autoMode = false
        mainHandler.removeCallbacks(autoRunnable)
        restoreSelectionChrome()
        btn.text = "手动"
        btn.background = GradientDrawable().apply {
            setColor(0xFF0EA5E9.toInt())
            shape = GradientDrawable.OVAL
        }
        setResult("已切回手动：点「译」翻译一次")
    }

    private fun scheduleAuto() {
        if (!autoMode) return
        mainHandler.removeCallbacks(autoRunnable)
        mainHandler.postDelayed(autoRunnable, AUTO_INTERVAL)
    }

    private fun autoTick() {
        if (!autoMode) return
        val sp = selParams
        if (sp == null || imageReader == null) { scheduleAuto(); return }
        if (busy) { scheduleAuto(); return }
        busy = true
        val needHide = fullScreen || resultOverlapsSelection(sp)
        val resultWasVisible = resultView?.visibility == View.VISIBLE
        if (needHide) mainHandler.post { resultView?.visibility = View.GONE }
        captureExec.execute {
            var done = false
            fun finish() {
                if (!done) {
                    done = true
                    busy = false
                    mainHandler.post {
                        if (resultWasVisible) resultView?.visibility = View.VISIBLE
                        scheduleAuto()
                    }
                }
            }
            try {
                try { Thread.sleep(110) } catch (e: InterruptedException) {}
                val crop = cropRegion(sp)
                if (needHide) mainHandler.post { if (resultWasVisible) resultView?.visibility = View.VISIBLE }
                if (crop == null) { finish(); return@execute }
                val sig = quickSignature(crop)
                lastSig = sig
                Ocr.recognize(crop) { text ->
                    val norm = text.replace((10).toChar(), (32).toChar()).replace((13).toChar(), (32).toChar()).replace((9).toChar(), (32).toChar()).trim()
                    val key = normKey(norm)
                    if (key.isBlank() || isDuplicateKey(key)) {
                        finish()
                    } else {
                        rememberKey(key)
                        lastUtterance = norm
                        Translator.translate(this, norm) { tr ->
                            pushTranslation(norm, tr)
                            finish()
                        }
                    }
                }
            } catch (e: Exception) {
                finish()
            }
        }
    }

    private fun normKey(s: String): String {
        val sb = StringBuilder()
        for (ch in s) {
            if (ch.isLetterOrDigit()) sb.append(ch.lowercaseChar())
        }
        return sb.toString()
    }

    private fun bigrams(s: String): HashSet<String> {
        val set = HashSet<String>()
        if (s.length < 2) {
            if (s.isNotEmpty()) set.add(s)
            return set
        }
        for (i in 0 until s.length - 1) set.add(s.substring(i, i + 2))
        return set
    }

    private fun isDuplicateKey(key: String): Boolean {
        if (key.isBlank()) return true
        for (k in recentKeys) {
            if (k == key) return true
            val a = bigrams(k)
            val b = bigrams(key)
            if (a.isEmpty() || b.isEmpty()) continue
            var inter = 0
            for (x in a) if (b.contains(x)) inter++
            val union = a.size + b.size - inter
            val sim = if (union == 0) 0f else inter.toFloat() / union
            if (sim > 0.88f) return true
        }
        return false
    }

    private fun rememberKey(key: String) {
        recentKeys.add(key)
        while (recentKeys.size > 8) recentKeys.removeAt(0)
    }

    private fun quickSignature(bmp: Bitmap): FloatArray {
        val gx = 16
        val gy = 10
        val arr = FloatArray(gx * gy)
        val maxX = (bmp.width - 1).coerceAtLeast(0)
        val maxY = (bmp.height - 1).coerceAtLeast(0)
        for (j in 0 until gy) {
            val py = if (gy <= 1) 0 else maxY * j / (gy - 1)
            for (i in 0 until gx) {
                val px = if (gx <= 1) 0 else maxX * i / (gx - 1)
                val c = bmp.getPixel(px, py)
                val r = (c shr 16) and 0xFF
                val g = (c shr 8) and 0xFF
                val b = c and 0xFF
                arr[j * gx + i] = r * 0.299f + g * 0.587f + b * 0.114f
            }
        }
        return arr
    }

    private fun sigDiff(a: FloatArray, b: FloatArray): Float {
        if (a.size != b.size) return 999f
        var s = 0f
        for (k in a.indices) {
            var d = a[k] - b[k]
            if (d < 0) d = -d
            s += d
        }
        return s / a.size
    }

    private fun hideSelectionChrome() {
        selectionView?.background = null
        selHandle?.visibility = View.INVISIBLE
    }

    private fun restoreSelectionChrome() {
        if (frameHidden) return
        selectionView?.background = selBg
        selHandle?.visibility = View.VISIBLE
    }

    private fun grabLatestBitmap(): Bitmap? {
        val reader = imageReader ?: return null
        var image: Image? = null
        val deadline = System.currentTimeMillis() + 800
        while (image == null && System.currentTimeMillis() < deadline) {
            image = reader.acquireLatestImage()
            if (image == null) {
                try {
                    Thread.sleep(30)
                } catch (e: InterruptedException) {
                }
            }
        }
        if (image == null) return null
        try {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * screenW
            val rawW = screenW + rowPadding / pixelStride
            val bmp = Bitmap.createBitmap(rawW, screenH, Bitmap.Config.ARGB_8888)
            bmp.copyPixelsFromBuffer(buffer)
            return if (bmp.width != screenW) {
                Bitmap.createBitmap(bmp, 0, 0, screenW, screenH)
            } else {
                bmp
            }
        } finally {
            image.close()
        }
    }

    private fun setResult(text: String) {
        mainHandler.post {
            try {
                Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
            }
        }
    }

    // ---------------- 清理 ----------------
    override fun onDestroy() {
        super.onDestroy()
        autoMode = false
        mainHandler.removeCallbacks(autoRunnable)
        try {
            virtualDisplay?.release()
        } catch (e: Exception) {
        }
        try {
            projection?.stop()
        } catch (e: Exception) {
        }
        try {
            imageReader?.close()
        } catch (e: Exception) {
        }
        removal(selectionView)
        removal(resultView)
        removal(controlView)
        selectionView = null
        resultView = null
        controlView = null
        captureExec.shutdownNow()
    }

    private fun removal(v: View?) {
        if (v == null) return
        try {
            wm.removeView(v)
        } catch (e: Exception) {
        }
    }

    companion object {
        private const val NOTIF_ID = 20240501_01
        private const val AUTO_INTERVAL = 1000L
        private const val SIG_THRESHOLD = 4f
    }
}
