package com.rorykosanke.fanyifloat

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

/** 端侧 OCR：同时用「拉丁文模型」和「中文模型」识别，取更合适的结果。 */
object Ocr {

    private val latin = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val chinese = TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())

    fun recognize(bitmap: Bitmap, onText: (String) -> Unit) {
        val image = InputImage.fromBitmap(bitmap, 0)

        var latinText: String? = null
        var chineseText: String? = null
        var remaining = 2

        fun done() {
            val cjk = chineseText
            val result = if (!cjk.isNullOrBlank() && cjk.any { isCJK(it) }) {
                // 画面里有中日韩文字，用中文模型的结果（它也能读英文）
                cjk
            } else {
                // 纯英文/数字场景，拉丁模型更准
                if (!latinText.isNullOrBlank()) latinText!! else (cjk ?: "")
            }
            onText(result.trim())
        }

        latin.process(image).addOnCompleteListener { task ->
            latinText = try { task.result.text } catch (e: Exception) { "" }
            remaining -= 1
            if (remaining == 0) done()
        }
        chinese.process(image).addOnCompleteListener { task ->
            chineseText = try { task.result.text } catch (e: Exception) { "" }
            remaining -= 1
            if (remaining == 0) done()
        }
    }

    private fun isCJK(c: Char): Boolean {
        val b = c.code
        return (b in 0x4E00..0x9FFF) ||   // 汉字
                (b in 0x3040..0x30FF) ||  // 日文假名
                (b in 0xAC00..0xD7AF)     // 韩文
    }
}
