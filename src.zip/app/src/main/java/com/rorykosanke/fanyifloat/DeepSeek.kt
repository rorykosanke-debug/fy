package com.rorykosanke.fanyifloat

import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/** 调用 DeepSeek 的 Chat Completions 接口做翻译。 */
object DeepSeek {

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private val JSON = "application/json; charset=utf-8".toMediaType()

    /**
     * 把 [text] 翻译成 [target]，结果（或错误提示）通过 [onResult] 回调。
     * 注意：onResult 在 OkHttp 的后台线程里执行，UI 更新请自行 post 到主线程。
     */
    fun translate(apiKey: String, target: String, text: String, onResult: (String) -> Unit) {
        if (apiKey.isBlank()) {
            onResult("❗ 未填写 DeepSeek API Key，请回 App 里设置")
            return
        }
        if (text.isBlank()) {
            onResult("（没有识别到文字）")
            return
        }

        val messages = JSONArray()
        messages.put(JSONObject().put("role", "system")
            .put("content", "你是一个只输出译文的翻译引擎。只输出翻译结果，不要解释、不要拼音、不要加引号。"))
        messages.put(JSONObject().put("role", "user")
            .put("content", "把下面的内容翻译成${target}，只输出译文：\n\n$text"))

        val bodyJson = JSONObject()
            .put("model", "deepseek-chat")
            .put("messages", messages)
            .put("stream", false)
            .put("temperature", 0.2)
            .toString()

        val request = Request.Builder()
            .url("https://api.deepseek.com/chat/completions")
            .header("Authorization", "Bearer $apiKey")
            .post(bodyJson.toRequestBody(JSON))
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                onResult("❗ 网络错误：${e.message ?: "连接失败"}")
            }

            override fun onResponse(call: Call, response: Response) {
                response.use { resp ->
                    val raw = resp.body?.string().orEmpty()
                    if (!resp.isSuccessful) {
                        onResult("❗ 接口错误 ${resp.code}：${raw.take(200)}")
                        return
                    }
                    try {
                        val content = JSONObject(raw)
                            .getJSONArray("choices")
                            .getJSONObject(0)
                            .getJSONObject("message")
                            .getString("content")
                            .trim()
                        onResult(content)
                    } catch (e: Exception) {
                        onResult("❗ 解析失败：${raw.take(200)}")
                    }
                }
            }
        })
    }
}
