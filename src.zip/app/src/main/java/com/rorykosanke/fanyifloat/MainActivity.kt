package com.rorykosanke.fanyifloat

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val RC_CAPTURE = 1001
    private val RC_NOTIF = 1002
    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(20), dp(24), dp(20), dp(24))
        root.setBackgroundColor(0xFF0B1220.toInt())

        val title = TextView(this)
        title.text = "悬浮翻译"
        title.setTextColor(0xFFFFFFFF.toInt())
        title.textSize = 24f
        title.setTypeface(null, android.graphics.Typeface.BOLD)
        root.addView(title)

        val subtitle = TextView(this)
        subtitle.text = "悬浮在微信视频上，框选英文/外文 → 点「译」→ DeepSeek 翻译"
        subtitle.setTextColor(0xFF8EA1BD.toInt())
        subtitle.textSize = 13f
        subtitle.setPadding(0, dp(6), 0, dp(18))
        root.addView(subtitle)

        root.addView(stepTitle("第 1 步 · 授权"))
        root.addView(primaryButton("开启悬浮窗权限") {
            if (Settings.canDrawOverlays(this)) {
                toast("已有悬浮窗权限 ✅")
            } else {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            }
        })

        root.addView(stepTitle("第 2 步 · DeepSeek"))
        root.addView(primaryButton("填写 API Key") { showKeyDialog() })
        root.addView(primaryButton("设置目标语言（当前：${Prefs.getTarget(this)}）") { showTargetDialog() })

        root.addView(stepTitle("第 3 步 · 启动"))
        val startBtn = accentButton("开始悬浮翻译") { startCapture() }
        root.addView(startBtn)

        statusText = TextView(this)
        statusText.setTextColor(0xFF22C55E.toInt())
        statusText.textSize = 13f
        statusText.setPadding(0, dp(14), 0, 0)
        statusText.text = ""
        root.addView(statusText)

        val help = TextView(this)
        help.text = "使用说明：\n" +
                "1. 依次完成上面 3 步（第一次会弹「屏幕录制/投屏」授权，点『立即开始』）。\n" +
                "2. 切到微信视频，会看到一个绿色选区框和一个竖排按钮。\n" +
                "3. 拖动选区框到字幕位置，可拖右下角绿点缩放大小。\n" +
                "4. 手动翻译：点「译」翻译一次，结果显示在框下方。\n" +
                "5. 自动翻译：点「自动」，画面文字一变就自动翻译；点「手动」关闭。\n\n" +
                "提示：字幕要清晰、框尽量只框住字幕，识别和翻译会更准。"
        help.setTextColor(0xFF56657D.toInt())
        help.textSize = 12f
        help.setPadding(0, dp(24), 0, 0)
        help.setLineSpacing(0f, 1.25f)
        root.addView(help)

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun stepTitle(t: String): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.setTextColor(0xFF22C55E.toInt())
        tv.textSize = 13f
        tv.setTypeface(null, android.graphics.Typeface.BOLD)
        tv.setPadding(0, dp(16), 0, dp(8))
        return tv
    }

    private fun baseButton(text: String, bg: Int, fg: Int): Button {
        val b = Button(this)
        b.text = text
        b.setTextColor(fg)
        b.textSize = 15f
        b.isAllCaps = false
        b.background = GradientDrawable().apply {
            setColor(bg)
            cornerRadius = dp(12).toFloat()
        }
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.bottomMargin = dp(10)
        b.layoutParams = lp
        b.setPadding(0, dp(12), 0, dp(12))
        b.stateListAnimator = null
        return b
    }

    private fun primaryButton(text: String, onClick: () -> Unit): Button {
        val b = baseButton(text, 0xFF182238.toInt(), 0xFFFFFFFF.toInt())
        b.setOnClickListener { onClick() }
        return b
    }

    private fun accentButton(text: String, onClick: () -> Unit): Button {
        val b = baseButton(text, 0xFF22C55E.toInt(), 0xFF06140A.toInt())
        b.setTypeface(null, android.graphics.Typeface.BOLD)
        b.setOnClickListener { onClick() }
        return b
    }

    private fun showKeyDialog() {
        val input = EditText(this)
        input.inputType = InputType.TYPE_CLASS_TEXT
        input.hint = "sk-..."
        input.setText(Prefs.getApiKey(this))
        input.setPadding(dp(12), dp(8), dp(12), dp(8))

        AlertDialog.Builder(this)
            .setTitle("DeepSeek API Key")
            .setMessage("在 platform.deepseek.com 注册后创建，形如 sk-xxxx")
            .setView(input)
            .setPositiveButton("保存") { _, _ ->
                Prefs.setApiKey(this, input.text.toString())
                toast("已保存 API Key")
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun showTargetDialog() {
        val input = EditText(this)
        input.inputType = InputType.TYPE_CLASS_TEXT
        input.hint = "简体中文"
        input.setText(Prefs.getTarget(this))
        input.setPadding(dp(12), dp(8), dp(12), dp(8))

        AlertDialog.Builder(this)
            .setTitle("翻译成什么语言？")
            .setView(input)
            .setPositiveButton("保存") { _, _ ->
                Prefs.setTarget(this, input.text.toString())
                toast("目标语言已设为目标：${Prefs.getTarget(this)}")
                buildUi()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun ensureNotifPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), RC_NOTIF)
        }
    }

    private fun startCapture() {
        if (!Settings.canDrawOverlays(this)) {
            toast("请先点「开启悬浮窗权限」")
            return
        }
        if (Prefs.getApiKey(this).isBlank()) {
            toast("请先填写 DeepSeek API Key")
            return
        }
        ensureNotifPermission()
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), RC_CAPTURE)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == RC_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                val i = Intent(this, OverlayService::class.java)
                i.putExtra("code", resultCode)
                i.putExtra("data", data)
                startForegroundService(i)
                statusText.text = "✅ 已启动，切到微信视频上点悬浮「译」"
                toast("已启动，切到微信视频上点「译」")
            } else {
                statusText.text = "已取消投屏授权"
                toast("已取消投屏授权")
            }
        }
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
