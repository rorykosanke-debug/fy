package com.rorykosanke.fanyifloat

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val RC_CAPTURE = 1001
    private val RC_NOTIF = 1002
    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun engineName(e: String): String = when (e) {
        "youdao" -> "有道（免费·无需Key·国内可直连）"
        "google" -> "Google（免费·无需Key·大陆常需梯子）"
        "microsoft" -> "微软（免费额度·需Azure Key）"
        else -> "DeepSeek（需Key）"
    }

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(20), dp(24), dp(20), dp(24))
        root.setBackgroundColor(0xFF0B1220.toInt())

        val title = TextView(this)
        title.text = "悬浮翻译"
        title.setTextColor(0xFFFFFFFF.toInt())
        title.textSize = 24f
        title.setTypeface(null, android.graphics.Typeface.BOLD)
        root.addView(title)

        val subtitle = TextView(this)
        subtitle.text = "悬浮在微信视频上，框选外文 → 自动/手动翻译"
        subtitle.setTextColor(0xFF8EA1BD.toInt())
        subtitle.textSize = 13f
        subtitle.setPadding(0, dp(6), 0, dp(18))
        root.addView(subtitle)

        root.addView(stepTitle("第 1 步 · 授权"))
        root.addView(primaryButton("开启悬浮窗权限") {
            if (Settings.canDrawOverlays(this)) toast("已有悬浮窗权限 ✅")
            else startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })

        root.addView(stepTitle("第 2 步 · 翻译引擎与语言"))
        root.addView(primaryButton("翻译引擎：${engineName(Prefs.getEngine(this))}（点这里切换）") { showEngineDialog() })
        root.addView(primaryButton("目标语言（当前：${Prefs.getTarget(this)}）") { showTargetDialog() })
        root.addView(primaryButton("显示模式：${if (Prefs.getDisplay(this) == "double") "双语（原文+译文）" else "单语（只显示译文）"}（点这里切换）") { toggleDisplay() })
        root.addView(primaryButton("DeepSeek Key（选 DeepSeek 时填）") { showKeyDialog() })
        root.addView(primaryButton("微软 Azure Key（选微软时填）") { showMsKeyDialog() })
        root.addView(primaryButton("微软区域 Region（如 eastasia）") { showMsRegionDialog() })

        root.addView(stepTitle("第 3 步 · 启动"))
        root.addView(accentButton("开始悬浮翻译") { startCapture() })

        statusText = TextView(this)
        statusText.setTextColor(0xFF22C55E.toInt())
        statusText.textSize = 13f
        statusText.setPadding(0, dp(14), 0, 0)
        statusText.text = ""
        root.addView(statusText)

        val help = TextView(this)
        help.text = "使用说明：\n" +
                "1. 依次完成上面 3 步（第一次会弹「屏幕录制/投屏」授权，点『立即开始』）。\n" +
                "2. 到微信视频，会看到绿色选区框和竖排按钮。\n" +
                "3. 拖选区框到字幕位置，拖右下角绿点缩放。\n" +
                "4. 自动翻译：点面板「手动」变「自动」，画面文字一变就自动翻译。\n" +
                "5. 手动翻译：点「译」翻译一次。\n" +
                "6. 上方「−」收起/展开；把面板拖到屏幕左/右边缘会自动贴边收起；「设」回设置；「✕」关闭。\n" +
                "7. 译文显示在框下方：最新在最下面，最多 3 行，旧的会淡出。\n\n" +
                "网络提示：Google 引擎在大陆常需科学上网；连不上就换“微软/DeepSeek”。"
        help.setTextColor(0xFF56657D.toInt())
        help.textSize = 12f
        help.setPadding(0, dp(24), 0, 0)
        help.setLineSpacing(0f, 1.25f)
        root.addView(help)

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun stepTitle(t: String): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.setTextColor(0xFF22C55E.toInt())
        tv.textSize = 13f
        tv.setTypeface(null, android.graphics.Typeface.BOLD)
        tv.setPadding(0, dp(16), 0, dp(8))
        return tv
    }

    private fun baseButton(text: String, bg: Int, fg: Int): Button {
        val b = Button(this)
        b.text = text
        b.setTextColor(fg)
        b.textSize = 15f
        b.isAllCaps = false
        b.background = GradientDrawable().apply {
            setColor(bg)
            cornerRadius = dp(12).toFloat()
        }
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.bottomMargin = dp(10)
        b.layoutParams = lp
        b.setPadding(0, dp(12), 0, dp(12))
        b.stateListAnimator = null
        return b
    }

    private fun primaryButton(text: String, onClick: () -> Unit): Button {
        val b = baseButton(text, 0xFF182238.toInt(), 0xFFFFFFFF.toInt())
        b.setOnClickListener { onClick() }
        return b
    }

    private fun accentButton(text: String, onClick: () -> Unit): Button {
        val b = baseButton(text, 0xFF22C55E.toInt(), 0xFF06140A.toInt())
        b.setTypeface(null, android.graphics.Typeface.BOLD)
        b.setOnClickListener { onClick() }
        return b
    }

    private fun showInputDialog(title: String, hint: String, initial: String, onSave: (String) -> Unit) {
        val input = EditText(this)
        input.inputType = InputType.TYPE_CLASS_TEXT
        input.hint = hint
        input.setText(initial)
        input.setPadding(dp(12), dp(8), dp(12), dp(8))
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(input)
            .setPositiveButton("保存") { _, _ -> onSave(input.text.toString()) }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun showKeyDialog() {
        showInputDialog("DeepSeek API Key", "sk-...", Prefs.getApiKey(this)) {
            Prefs.setApiKey(this, it); toast("已保存 DeepSeek Key")
        }
    }

    private fun showMsKeyDialog() {
        showInputDialog("微软 Azure Key", "Azure 翻译资源的 Key", Prefs.getMsKey(this)) {
            Prefs.setMsKey(this, it); toast("已保存微软 Key")
        }
    }

    private fun showMsRegionDialog() {
        showInputDialog("微软区域 Region", "如 eastasia / southeastasia / global", Prefs.getMsRegion(this)) {
            Prefs.setMsRegion(this, it); toast("已保存区域")
        }
    }

    private fun showEngineDialog() {
        val engines = arrayOf("youdao", "google", "microsoft", "deepseek")
        val names = arrayOf(
            "有道翻译（免费·无需Key·国内可直连，推荐）",
            "Google 翻译（免费·无需Key·大陆常需梯子）",
            "微软翻译（有免费额度，但要 Azure Key 才能调）",
            "DeepSeek（需Key，译文最自然）"
        )
        val cur = engines.indexOf(Prefs.getEngine(this)).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("选择翻译引擎")
            .setSingleChoiceItems(names, cur) { d, which ->
                Prefs.setEngine(this, engines[which])
                d.dismiss()
                buildUi()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun toggleDisplay() {
        Prefs.setDisplay(this, if (Prefs.getDisplay(this) == "double") "single" else "double")
        buildUi()
    }

    private fun showTargetDialog() {
        showInputDialog("翻译成什么语言？", "简体中文", Prefs.getTarget(this)) {
            Prefs.setTarget(this, it)
            toast("目标语言：${Prefs.getTarget(this)}")
            buildUi()
        }
    }

    private fun ensureNotifPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), RC_NOTIF)
        }
    }

    private fun startCapture() {
        if (!Settings.canDrawOverlays(this)) {
            toast("请先点「开启悬浮窗权限」")
            return
        }
        val engine = Prefs.getEngine(this)
        if (engine == "deepseek" && Prefs.getApiKey(this).isBlank()) {
            toast("DeepSeek 引擎需要先填 Key")
            return
        }
        if (engine == "microsoft" && (Prefs.getMsKey(this).isBlank() || Prefs.getMsRegion(this).isBlank())) {
            toast("微软引擎需要填 Key 和 区域")
            return
        }
        ensureNotifPermission()
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), RC_CAPTURE)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == RC_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                val i = Intent(this, OverlayService::class.java)
                i.putExtra("code", resultCode)
                i.putExtra("data", data)
                startForegroundService(i)
                statusText.text = "✅ 已启动，切到微信视频上点「自动」或「译」"
                toast("已启动")
            } else {
                statusText.text = "已取消投屏授权"
                toast("已取消投屏授权")
            }
        }
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
