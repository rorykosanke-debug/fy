package com.rorykosanke.fanyifloat

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val RC_CAPTURE = 1001
    private val RC_NOTIF = 1002
    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(20), dp(24), dp(20), dp(24))
        root.setBackgroundColor(0xFF0B1220.toInt())

        val title = TextView(this)
        title.text = "悬浮翻译"
        title.setTextColor(0xFFFFFFFF.toInt())
        title.textSize = 24f
        title.setTypeface(null, android.graphics.Typeface.BOLD)
        root.addView(title)

        val subtitle = TextView(this)
        subtitle.text = "悬浮在视频上，框选外文 → 自动/手动翻译（DeepSeek 引擎）"
        subtitle.setTextColor(0xFF8EA1BD.toInt())
        subtitle.textSize = 13f
        subtitle.setPadding(0, dp(6), 0, dp(14))
        root.addView(subtitle)

        root.addView(primaryButton("① 开启悬浮窗权限") {
            if (Settings.canDrawOverlays(this)) toast("已有悬浮窗权限 ✅")
            else startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })

        root.addView(stepTitle("翻译设置"))
        val keyBtn = primaryButton(if (Prefs.getApiKey(this).isBlank()) "② DeepSeek API Key（点这里填写·必填）" else "② DeepSeek Key：已填写 ✓（点这里修改）") { showKeyDialog() }
        root.addView(keyBtn)
        root.addView(primaryButton("目标语言：${Prefs.getTarget(this)}") { showTargetDialog() })
        root.addView(primaryButton("显示：${if (Prefs.getDisplay(this) == "double") "双语(原文+译文)" else "单语(只译文)"}") { toggleDisplay() })
        root.addView(primaryButton("📄 翻译记录（按时间/内容分类）") { startActivity(Intent(this, HistoryActivity::class.java)) })

        root.addView(stepTitle("启动"))
        root.addView(accentButton("③ 开始悬浮翻译") { startCapture() })

        statusText = TextView(this)
        statusText.setTextColor(0xFF22C55E.toInt())
        statusText.textSize = 13f
        statusText.setPadding(0, dp(12), 0, 0)
        statusText.text = ""
        root.addView(statusText)

        val help = TextView(this)
        help.text = "用法：\n" +
                "1. 先填 DeepSeek API Key（platform.deepseek.com 注册创建，形如 sk-...）。\n" +
                "2. 点「开始」→ 弹屏幕录制授权 → 允许。\n" +
                "3. 切到视频，绿色框圈住字幕（只圈英文那行更准），拖右下角绿点缩放。\n" +
                "4. 面板：手动·自动 / 译 / 全(全屏) / 声(朗读) / 设 / ✕。\n" +
                "5. 自动：点「手动」变红「自动」，画面文字一变就翻。全：翻整屏。\n" +
                "6. 译文框右上角「收起」可关闭整个译文框；每行右侧 ✕ 关单行。\n" +
                "7. 面板拖到屏幕左右边缘会收成一条细边。\n\n" +
                "提示：译文串行，多半是视频自带中英双语字幕被一起识别的——框只框英文行即可。"
        help.setTextColor(0xFF56657D.toInt())
        help.textSize = 12f
        help.setPadding(0, dp(20), 0, 0)
        help.setLineSpacing(0f, 1.25f)
        root.addView(help)

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun stepTitle(t: String): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.setTextColor(0xFF22C55E.toInt())
        tv.textSize = 13f
        tv.setTypeface(null, android.graphics.Typeface.BOLD)
        tv.setPadding(0, dp(16), 0, dp(8))
        return tv
    }

    private fun baseButton(text: String, bg: Int, fg: Int): Button {
        val b = Button(this)
        b.text = text
        b.setTextColor(fg)
        b.textSize = 15f
        b.isAllCaps = false
        b.background = GradientDrawable().apply {
            setColor(bg)
            cornerRadius = dp(12).toFloat()
        }
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.bottomMargin = dp(10)
        b.layoutParams = lp
        b.setPadding(0, dp(12), 0, dp(12))
        b.stateListAnimator = null
        return b
    }

    private fun primaryButton(text: String, onClick: () -> Unit): Button {
        val b = baseButton(text, 0xFF182238.toInt(), 0xFFFFFFFF.toInt())
        b.setOnClickListener { onClick() }
        return b
    }

    private fun accentButton(text: String, onClick: () -> Unit): Button {
        val b = baseButton(text, 0xFF22C55E.toInt(), 0xFF06140A.toInt())
        b.setTypeface(null, android.graphics.Typeface.BOLD)
        b.setOnClickListener { onClick() }
        return b
    }

    private fun showKeyDialog() {
        val input = EditText(this)
        input.inputType = InputType.TYPE_CLASS_TEXT
        input.hint = "sk-..."
        input.setText(Prefs.getApiKey(this))
        input.setPadding(dp(12), dp(8), dp(12), dp(8))
        AlertDialog.Builder(this)
            .setTitle("DeepSeek API Key")
            .setMessage("在 platform.deepseek.com 注册后创建，形如 sk-xxxx")
            .setView(input)
            .setPositiveButton("保存") { _, _ ->
                Prefs.setApiKey(this, input.text.toString())
                toast("已保存 DeepSeek Key")
                buildUi()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun toggleDisplay() {
        Prefs.setDisplay(this, if (Prefs.getDisplay(this) == "double") "single" else "double")
        buildUi()
    }

    private fun showTargetDialog() {
        val input = EditText(this)
        input.inputType = InputType.TYPE_CLASS_TEXT
        input.hint = "简体中文"
        input.setText(Prefs.getTarget(this))
        input.setPadding(dp(12), dp(8), dp(12), dp(8))
        AlertDialog.Builder(this)
            .setTitle("翻译成什么语言？")
            .setView(input)
            .setPositiveButton("保存") { _, _ ->
                Prefs.setTarget(this, input.text.toString())
                toast("目标语言：${Prefs.getTarget(this)}")
                buildUi()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun ensureNotifPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), RC_NOTIF)
        }
    }

    private fun startCapture() {
        if (!Settings.canDrawOverlays(this)) {
            toast("请先点「开启悬浮窗权限」")
            return
        }
        if (Prefs.getApiKey(this).isBlank()) {
            toast("请先填写 DeepSeek API Key")
            return
        }
        ensureNotifPermission()
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), RC_CAPTURE)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == RC_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                val i = Intent(this, OverlayService::class.java)
                i.putExtra("code", resultCode)
                i.putExtra("data", data)
                startForegroundService(i)
                statusText.text = "✅ 已启动，切到视频上点「自动」或「译」"
                toast("已启动")
            } else {
                statusText.text = "已取消投屏授权"
                toast("已取消投屏授权")
            }
        }
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
