package com.rorykosanke.fanyifloat

import android.content.Context

/** 本地设置存储：翻译引擎、各家 Key、目标语言、显示模式、选区位置。 */
object Prefs {
    private const val NAME = "settings"
    private const val KEY_API = "deepseek_api_key"
    private const val KEY_TARGET = "target_lang"
    private const val KEY_SEL = "sel_bounds"
    private const val KEY_ENGINE = "engine"
    private const val KEY_MS_KEY = "ms_key"
    private const val KEY_MS_REGION = "ms_region"
    private const val KEY_DISPLAY = "display_mode"

    private fun sp(c: Context) = c.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun getApiKey(c: Context): String = sp(c).getString(KEY_API, "").orEmpty()
    fun setApiKey(c: Context, v: String) {
        sp(c).edit().putString(KEY_API, v.trim()).apply()
    }

    fun getTarget(c: Context): String = sp(c).getString(KEY_TARGET, "简体中文").orEmpty()
    fun setTarget(c: Context, v: String) {
        sp(c).edit().putString(KEY_TARGET, v.trim().ifBlank { "简体中文" }).apply()
    }

    // 翻译引擎：youdao / google / microsoft / deepseek
    fun getEngine(c: Context): String = sp(c).getString(KEY_ENGINE, "combined").orEmpty()
    fun setEngine(c: Context, v: String) {
        sp(c).edit().putString(KEY_ENGINE, v).apply()
    }

    fun getMsKey(c: Context): String = sp(c).getString(KEY_MS_KEY, "").orEmpty()
    fun setMsKey(c: Context, v: String) {
        sp(c).edit().putString(KEY_MS_KEY, v.trim()).apply()
    }

    fun getMsRegion(c: Context): String = sp(c).getString(KEY_MS_REGION, "").orEmpty()
    fun setMsRegion(c: Context, v: String) {
        sp(c).edit().putString(KEY_MS_REGION, v.trim()).apply()
    }

    // 显示模式：single 只显示译文 / double 原文+译文分开显示
    fun getDisplay(c: Context): String = sp(c).getString(KEY_DISPLAY, "single").orEmpty()
    fun setDisplay(c: Context, v: String) {
        sp(c).edit().putString(KEY_DISPLAY, v).apply()
    }

    fun saveSelBounds(c: Context, x: Int, y: Int, w: Int, h: Int) {
        sp(c).edit().putString(KEY_SEL, "$x,$y,$w,$h").apply()
    }

    fun getSelBounds(c: Context): IntArray? {
        val s = sp(c).getString(KEY_SEL, null) ?: return null
        val p = s.split(",")
        if (p.size != 4) return null
        return try {
            intArrayOf(p[0].toInt(), p[1].toInt(), p[2].toInt(), p[3].toInt())
        } catch (e: Exception) {
            null
        }
    }
}
