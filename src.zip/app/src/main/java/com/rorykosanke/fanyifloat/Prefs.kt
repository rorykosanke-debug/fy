package com.rorykosanke.fanyifloat

import android.content.Context

/** 简单的本地设置存储：API Key、目标语言。 */
object Prefs {
    private const val NAME = "settings"
    private const val KEY_API = "deepseek_api_key"
    private const val KEY_TARGET = "target_lang"
    private const val KEY_SEL = "sel_bounds"

    private fun sp(c: Context) = c.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun getApiKey(c: Context): String = sp(c).getString(KEY_API, "").orEmpty()
    fun setApiKey(c: Context, v: String) {
        sp(c).edit().putString(KEY_API, v.trim()).apply()
    }

    fun getTarget(c: Context): String = sp(c).getString(KEY_TARGET, "简体中文").orEmpty()
    fun setTarget(c: Context, v: String) {
        sp(c).edit().putString(KEY_TARGET, v.trim().ifBlank { "简体中文" }).apply()
    }

    fun saveSelBounds(c: Context, x: Int, y: Int, w: Int, h: Int) {
        sp(c).edit().putString(KEY_SEL, "$x,$y,$w,$h").apply()
    }

    fun getSelBounds(c: Context): IntArray? {
        val s = sp(c).getString(KEY_SEL, null) ?: return null
        val p = s.split(",")
        if (p.size != 4) return null
        return try {
            intArrayOf(p[0].toInt(), p[1].toInt(), p[2].toInt(), p[3].toInt())
        } catch (e: Exception) {
            null
        }
    }
}
