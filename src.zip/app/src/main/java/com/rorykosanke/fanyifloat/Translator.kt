package com.rorykosanke.fanyifloat

import android.content.Context
import okhttp3.Call
import okhttp3.Callback
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.FormBody
import okhttp3.HttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * 翻译入口：
 *  - deepseek : DeepSeek 官方 API（https://api.deepseek.com，需 Key，稳定）
 *  - custom   : 自定义 OpenAI 兼容接口（自填 Base/Key/模型，可随时换 Key 不用重装 App）
 *  - tencent  : 腾讯翻译君免费网页接口（免Key；逆向接口，令牌常变，可能失效）
 */
object Translator {

    private const val UA = "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"
    private val JSON = "application/json; charset=utf-8".toMediaType()

    private val cookieStore = HashMap<String, List<Cookie>>()
    private val cookieJar = object : CookieJar {
        override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) {
            synchronized(cookieStore) { cookieStore[url.host] = cookies }
        }

        override fun loadForRequest(url: HttpUrl): List<Cookie> {
            synchronized(cookieStore) { return cookieStore[url.host] ?: emptyList() }
        }
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .followRedirects(true)
        .cookieJar(cookieJar)
        .build()

    private fun ok(s: String): Boolean = s.isNotBlank() && !s.startsWith("❗")

    fun translate(ctx: Context, text: String, onResult: (String) -> Unit) {
        val t = text.trim()
        if (t.isBlank()) {
            onResult("（没有识别到文字）")
            return
        }
        val target = Prefs.getTarget(ctx)
        when (Prefs.getEngine(ctx)) {
            "custom" -> chatTranslate(
                Prefs.getCustomBase(ctx), Prefs.getCustomKey(ctx), Prefs.getCustomModel(ctx), t, target, onResult
            )
            "glm" -> chatTranslate(
                "https://open.bigmodel.cn/api/paas/v4", Prefs.getGlmKey(ctx), "glm-4-flash", t, target
            ) { r ->
                if (ok(r)) onResult(r)
                else if (Prefs.getApiKey(ctx).isNotBlank())
                    chatTranslate("https://api.deepseek.com", Prefs.getApiKey(ctx), "deepseek-chat", t, target) { r2 ->
                        onResult(if (ok(r2)) r2 else r)
                    }
                else onResult(r)
            }
            else -> chatTranslate(
                "https://api.deepseek.com", Prefs.getApiKey(ctx), "deepseek-chat", t, target, onResult
            )
        }
    }

    /** OpenAI 兼容的 chat/completions 翻译（DeepSeek、智谱、千问、豆包等通用）。 */
    private fun chatTranslate(base0: String, key: String, model: String, text: String, target: String, onResult: (String) -> Unit) {
        val base = base0.trim().trimEnd('/')
        if (key.isBlank()) {
            onResult("❗ 未填写 API Key（请在设置里填，或切换引擎）")
            return
        }
        if (base.isBlank()) {
            onResult("❗ 未填写接口地址(Base URL)")
            return
        }
        val messages = JSONArray()
        messages.put(JSONObject().put("role", "system")
            .put("content", "你是翻译引擎，只输出译文，不要解释、不要拼音。"))
        messages.put(JSONObject().put("role", "user")
            .put("content", "把下面的内容翻译成${target}，只输出译文：\n\n$text"))
        val body = JSONObject()
            .put("model", model.ifBlank { "deepseek-chat" })
            .put("messages", messages)
            .put("stream", false)
            .put("temperature", 0.2)
            .toString()
        val req = Request.Builder()
            .url("$base/chat/completions")
            .header("Authorization", "Bearer $key")
            .header("Content-Type", "application/json")
            .post(body.toRequestBody(JSON))
            .build()
        client.newCall(req).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                onResult("❗ 网络错误：${e.message ?: "连接失败"}")
            }

            override fun onResponse(call: Call, response: Response) {
                response.use { resp ->
                    val raw = resp.body?.string().orEmpty()
                    if (!resp.isSuccessful) {
                        onResult("❗ 接口错误 ${resp.code}：${raw.take(160)}")
                        return
                    }
                    try {
                        onResult(JSONObject(raw).getJSONArray("choices").getJSONObject(0)
                            .getJSONObject("message").getString("content").trim())
                    } catch (e: Exception) {
                        onResult("❗ 解析失败：" + raw.take(160))
                    }
                }
            }
        })
    }

    private fun tcTarget(target: String): String {
        val s = target.lowercase()
        return when {
            s.contains("英") -> "en"
            s.contains("日") -> "jp"
            s.contains("韩") || s.contains("韓") -> "kr"
            else -> "zh"
        }
    }

    private fun tencent(text: String, target: String, onResult: (String) -> Unit) {
        val pageReq = Request.Builder().url("https://fanyi.qq.com/").header("User-Agent", UA).get().build()
        client.newCall(pageReq).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                onResult("❗ 腾讯网络错误：${e.message ?: "连接失败"}")
            }

            override fun onResponse(call: Call, response: Response) {
                val html = try {
                    response.use { it.body?.string().orEmpty() }
                } catch (e: Exception) {
                    ""
                }
                val qtv = findToken(html, "qtv")
                val qcv = findToken(html, "qcv")
                if (qtv == null || qcv == null) {
                    onResult("❗ 腾讯接口取令牌失败（接口已改动，建议用 DeepSeek/自定义）")
                    return
                }
                val form = FormBody.Builder()
                    .add("source", "auto")
                    .add("target", tcTarget(target))
                    .add("sourceText", text)
                    .add("qtv", qtv)
                    .add("qcv", qcv)
                    .add("sessionUuid", "translate_uuid" + System.currentTimeMillis())
                    .build()
                val postReq = Request.Builder().url("https://fanyi.qq.com/api/translate")
                    .header("User-Agent", UA).header("Referer", "https://fanyi.qq.com/")
                    .post(form).build()
                client.newCall(postReq).enqueue(object : Callback {
                    override fun onFailure(call: Call, e: IOException) {
                        onResult("❗ 腾讯网络错误：${e.message ?: "连接失败"}")
                    }

                    override fun onResponse(call: Call, response: Response) {
                        response.use { resp ->
                            val raw = resp.body?.string().orEmpty()
                            if (!resp.isSuccessful) {
                                onResult("❗ 腾讯接口错误 ${resp.code}")
                                return
                            }
                            try {
                                val obj = JSONObject(raw)
                                val tr = obj.optJSONObject("translate")
                                val errCode = tr?.optInt("errCode", 0) ?: 0
                                val recs = tr?.optJSONArray("records")
                                val sb = StringBuilder()
                                if (recs != null) for (i in 0 until recs.length()) {
                                    sb.append(recs.getJSONObject(i).optString("targetText"))
                                }
                                val out = sb.toString().trim()
                                if (errCode != 0 || out.isBlank()) onResult("❗ 腾讯返回空（errCode=$errCode）")
                                else onResult(out)
                            } catch (e: Exception) {
                                onResult("❗ 腾讯解析失败：" + raw.take(120))
                            }
                        }
                    }
                })
            }
        })
    }

    private fun findToken(html: String, name: String): String? {
        val re = Regex(name + "\\s*=\\s*[\"']([^\"']+)[\"']")
        return re.find(html)?.groupValues?.get(1)
    }
}
