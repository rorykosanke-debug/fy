package com.rorykosanke.fanyifloat

import android.content.Context
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * 翻译入口：只用 DeepSeek（稳定、译文质量好）。
 * 有道/Google/微软 已按用户要求移除——这些免费接口在国内经常连不上，导致“翻译失效”。
 */
object Translator {

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private val JSON = "application/json; charset=utf-8".toMediaType()

    fun translate(ctx: Context, text: String, onResult: (String) -> Unit) {
        val t = text.trim()
        if (t.isBlank()) {
            onResult("（没有识别到文字）")
            return
        }
        deepseek(Prefs.getApiKey(ctx), t, Prefs.getTarget(ctx), onResult)
    }

    private fun callback(onResult: (String) -> Unit, parse: (String) -> String): Callback {
        return object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                onResult("❗ 网络错误：${e.message ?: "连接失败"}")
            }

            override fun onResponse(call: Call, response: Response) {
                response.use { resp ->
                    val raw = resp.body?.string().orEmpty()
                    if (!resp.isSuccessful) {
                        onResult("❗ 接口错误 ${resp.code}：${raw.take(160)}")
                        return
                    }
                    try {
                        onResult(parse(raw))
                    } catch (e: Exception) {
                        onResult("❗ 解析失败：${raw.take(160)}")
                    }
                }
            }
        }
    }

    private fun deepseek(apiKey: String, text: String, target: String, onResult: (String) -> Unit) {
        if (apiKey.isBlank()) {
            onResult("❗ 请先在设置里填写 DeepSeek API Key")
            return
        }
        val messages = JSONArray()
        messages.put(JSONObject().put("role", "system")
            .put("content", "你是翻译引擎，只输出译文，不要解释、不要拼音。"))
        messages.put(JSONObject().put("role", "user")
            .put("content", "把下面的内容翻译成${target}，只输出译文：\n\n$text"))
        val body = JSONObject()
            .put("model", "deepseek-chat")
            .put("messages", messages)
            .put("stream", false)
            .put("temperature", 0.2)
            .toString()
        val req = Request.Builder()
            .url("https://api.deepseek.com/chat/completions")
            .header("Authorization", "Bearer $apiKey")
            .post(body.toRequestBody(JSON))
            .build()
        client.newCall(req).enqueue(callback(onResult) { raw ->
            JSONObject(raw).getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").getString("content").trim()
        })
    }
}
