package com.rorykosanke.fanyifloat

import android.content.Context
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/**
 * 统一翻译入口，支持三种引擎：
 *  - google    : 谷歌免费接口（无需 Key；大陆可能需科学上网）
 *  - microsoft : 微软 Azure 翻译（免费额度 F0；需 Key + 区域）
 *  - deepseek  : DeepSeek（需 Key）
 */
object Translator {

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private val JSON = "application/json; charset=utf-8".toMediaType()

    fun translate(ctx: Context, text: String, onResult: (String) -> Unit) {
        val t = text.trim()
        if (t.isBlank()) {
            onResult("（没有识别到文字）")
            return
        }
        val target = Prefs.getTarget(ctx)
        when (Prefs.getEngine(ctx)) {
            "google" -> google(t, target, onResult)
            "microsoft" -> microsoft(Prefs.getMsKey(ctx), Prefs.getMsRegion(ctx), t, target, onResult)
            else -> deepseek(Prefs.getApiKey(ctx), t, target, onResult)
        }
    }

    private fun gCode(target: String): String {
        val s = target.lowercase()
        return when {
            s.contains("繁") || s.contains("台湾") || s.contains("繁體") -> "zh-TW"
            s.contains("中") || s.contains("汉语") || s.contains("中文") -> "zh-CN"
            s.contains("英") || s.contains("english") -> "en"
            s.contains("日") || s.contains("japan") -> "ja"
            s.contains("韩") || s.contains("韓") || s.contains("korea") -> "ko"
            s.contains("法") || s.contains("french") -> "fr"
            s.contains("德") || s.contains("german") -> "de"
            s.contains("西") || s.contains("spanish") -> "es"
            s.contains("俄") || s.contains("russian") -> "ru"
            else -> "zh-CN"
        }
    }

    private fun msCode(target: String): String {
        val s = target.lowercase()
        return when {
            s.contains("繁") || s.contains("台湾") || s.contains("繁體") -> "zh-Hant"
            s.contains("中") || s.contains("汉语") -> "zh-Hans"
            s.contains("英") -> "en"
            s.contains("日") -> "ja"
            s.contains("韩") || s.contains("韓") -> "ko"
            s.contains("法") -> "fr"
            s.contains("德") -> "de"
            s.contains("西") -> "es"
            s.contains("俄") -> "ru"
            else -> "zh-Hans"
        }
    }

    private fun callback(onResult: (String) -> Unit, parse: (String) -> String): Callback {
        return object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                onResult("❗ 网络错误：${e.message ?: "连接失败"}")
            }

            override fun onResponse(call: Call, response: Response) {
                response.use { resp ->
                    val raw = resp.body?.string().orEmpty()
                    if (!resp.isSuccessful) {
                        onResult("❗ 接口错误 ${resp.code}：${raw.take(160)}")
                        return
                    }
                    try {
                        onResult(parse(raw))
                    } catch (e: Exception) {
                        onResult("❗ 解析失败：${raw.take(160)}")
                    }
                }
            }
        }
    }

    private fun deepseek(apiKey: String, text: String, target: String, onResult: (String) -> Unit) {
        if (apiKey.isBlank()) {
            onResult("❗ 请先在设置里填 DeepSeek Key，或把引擎换成 Google/微软")
            return
        }
        val messages = JSONArray()
        messages.put(JSONObject().put("role", "system")
            .put("content", "你是翻译引擎，只输出译文，不要解释、不要拼音。"))
        messages.put(JSONObject().put("role", "user")
            .put("content", "把下面内容翻译成${target}，只输出译文：\n\n$text"))
        val body = JSONObject()
            .put("model", "deepseek-chat")
            .put("messages", messages)
            .put("stream", false)
            .put("temperature", 0.2)
            .toString()
        val req = Request.Builder()
            .url("https://api.deepseek.com/chat/completions")
            .header("Authorization", "Bearer $apiKey")
            .post(body.toRequestBody(JSON))
            .build()
        client.newCall(req).enqueue(callback(onResult) { raw ->
            JSONObject(raw).getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").getString("content").trim()
        })
    }

    private fun google(text: String, target: String, onResult: (String) -> Unit) {
        val url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=" +
                gCode(target) + "&dt=t&q=" + URLEncoder.encode(text, "UTF-8")
        val req = Request.Builder().url(url)
            .header("User-Agent", "Mozilla/5.0")
            .get()
            .build()
        client.newCall(req).enqueue(callback(onResult) { raw ->
            val seg = JSONArray(raw).getJSONArray(0)
            val sb = StringBuilder()
            for (i in 0 until seg.length()) {
                sb.append(seg.getJSONArray(i).getString(0))
            }
            sb.toString().trim()
        })
    }

    private fun microsoft(key: String, region: String, text: String, target: String, onResult: (String) -> Unit) {
        if (key.isBlank()) {
            onResult("❗ 微软翻译需要 Azure 的 Key 和区域，请在设置里填，或换 Google")
            return
        }
        val body = JSONArray().put(JSONObject().put("Text", text)).toString()
        val req = Request.Builder()
            .url("https://api.cognitive.microsofttranslator.com/translate?api-version=3.0&to=" + msCode(target))
            .header("Ocp-Apim-Subscription-Key", key)
            .header("Ocp-Apim-Subscription-Region", region.ifBlank { "global" })
            .post(body.toRequestBody(JSON))
            .build()
        client.newCall(req).enqueue(callback(onResult) { raw ->
            JSONArray(raw).getJSONObject(0)
                .getJSONArray("translations").getJSONObject(0).getString("text").trim()
        })
    }
}
