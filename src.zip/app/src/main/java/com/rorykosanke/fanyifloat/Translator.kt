package com.rorykosanke.fanyifloat

import android.content.Context
import okhttp3.Call
import okhttp3.Callback
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.FormBody
import okhttp3.HttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * 翻译入口：
 *  - tencent  : 腾讯翻译君免费网页接口（免注册免Key，国内可直连；逆向接口，可能偶发失效）
 *  - deepseek : DeepSeek（需Key，稳定）
 * 当引擎=腾讯且腾讯失败时，如果填了 DeepSeek Key，会自动退回 DeepSeek。
 */
object Translator {

    private const val UA = "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"
    private val JSON = "application/json; charset=utf-8".toMediaType()

    private val cookieStore = HashMap<String, List<Cookie>>()
    private val cookieJar = object : CookieJar {
        override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) {
            synchronized(cookieStore) { cookieStore[url.host] = cookies }
        }

        override fun loadForRequest(url: HttpUrl): List<Cookie> {
            synchronized(cookieStore) { return cookieStore[url.host] ?: emptyList() }
        }
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .followRedirects(true)
        .cookieJar(cookieJar)
        .build()

    private fun ok(s: String): Boolean = s.isNotBlank() && !s.startsWith("❗")

    fun translate(ctx: Context, text: String, onResult: (String) -> Unit) {
        val t = text.trim()
        if (t.isBlank()) {
            onResult("（没有识别到文字）")
            return
        }
        val target = Prefs.getTarget(ctx)
        if (Prefs.getEngine(ctx) == "deepseek") {
            deepseek(Prefs.getApiKey(ctx), t, target, onResult)
        } else {
            // 默认腾讯免费，失败且有 DeepSeek Key 时自动退回
            tencent(t, target) { r ->
                if (ok(r)) {
                    onResult(r)
                } else if (Prefs.getApiKey(ctx).isNotBlank()) {
                    deepseek(Prefs.getApiKey(ctx), t, target) { r2 ->
                        onResult(if (ok(r2)) r2 else r)
                    }
                } else {
                    onResult(r)
                }
            }
        }
    }

    private fun tcTarget(target: String): String {
        val s = target.lowercase()
        return when {
            s.contains("英") -> "en"
            s.contains("日") -> "jp"
            s.contains("韩") || s.contains("韓") -> "kr"
            else -> "zh"
        }
    }

    /** 腾讯翻译君免费接口：先取 qtv/qcv 令牌，再 POST 翻译。 */
    private fun tencent(text: String, target: String, onResult: (String) -> Unit) {
        val pageReq = Request.Builder()
            .url("https://fanyi.qq.com/")
            .header("User-Agent", UA)
            .get()
            .build()
        client.newCall(pageReq).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                onResult("❗ 腾讯网络错误：${e.message ?: "连接失败"}")
            }

            override fun onResponse(call: Call, response: Response) {
                val html = try {
                    response.use { it.body?.string().orEmpty() }
                } catch (e: Exception) {
                    ""
                }
                val qtv = findToken(html, "qtv")
                val qcv = findToken(html, "qcv")
                if (qtv == null || qcv == null) {
                    onResult("❗ 腾讯接口取令牌失败（接口可能已改）")
                    return
                }
                val form = FormBody.Builder()
                    .add("source", "auto")
                    .add("target", tcTarget(target))
                    .add("sourceText", text)
                    .add("qtv", qtv)
                    .add("qcv", qcv)
                    .add("sessionUuid", "translate_uuid" + System.currentTimeMillis())
                    .build()
                val postReq = Request.Builder()
                    .url("https://fanyi.qq.com/api/translate")
                    .header("User-Agent", UA)
                    .header("Referer", "https://fanyi.qq.com/")
                    .post(form)
                    .build()
                client.newCall(postReq).enqueue(object : Callback {
                    override fun onFailure(call: Call, e: IOException) {
                        onResult("❗ 腾讯网络错误：${e.message ?: "连接失败"}")
                    }

                    override fun onResponse(call: Call, response: Response) {
                        response.use { resp ->
                            val raw = resp.body?.string().orEmpty()
                            if (!resp.isSuccessful) {
                                onResult("❗ 腾讯接口错误 ${resp.code}")
                                return
                            }
                            try {
                                val obj = JSONObject(raw)
                                val tr = obj.optJSONObject("translate")
                                val errCode = tr?.optInt("errCode", 0) ?: 0
                                val recs = tr?.optJSONArray("records")
                                val sb = StringBuilder()
                                if (recs != null) {
                                    for (i in 0 until recs.length()) {
                                        sb.append(recs.getJSONObject(i).optString("targetText"))
                                    }
                                }
                                val out = sb.toString().trim()
                                if (errCode != 0 || out.isBlank()) {
                                    onResult("❗ 腾讯返回空（errCode=$errCode）")
                                } else {
                                    onResult(out)
                                }
                            } catch (e: Exception) {
                                onResult("❗ 腾讯解析失败：" + raw.take(120))
                            }
                        }
                    }
                })
            }
        })
    }

    private fun findToken(html: String, name: String): String? {
        val re = Regex(name + "\\s*=\\s*[\"']([^\"']+)[\"']")
        return re.find(html)?.groupValues?.get(1)
    }

    private fun deepseek(apiKey: String, text: String, target: String, onResult: (String) -> Unit) {
        if (apiKey.isBlank()) {
            onResult("❗ 请先在设置里填写 DeepSeek API Key（或改用腾讯免费）")
            return
        }
        val messages = JSONArray()
        messages.put(JSONObject().put("role", "system")
            .put("content", "你是翻译引擎，只输出译文，不要解释、不要拼音。"))
        messages.put(JSONObject().put("role", "user")
            .put("content", "把下面的内容翻译成${target}，只输出译文：\n\n$text"))
        val body = JSONObject()
            .put("model", "deepseek-chat")
            .put("messages", messages)
            .put("stream", false)
            .put("temperature", 0.2)
            .toString()
        val req = Request.Builder()
            .url("https://api.deepseek.com/chat/completions")
            .header("Authorization", "Bearer $apiKey")
            .post(body.toRequestBody(JSON))
            .build()
        client.newCall(req).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                onResult("❗ 网络错误：${e.message ?: "连接失败"}")
            }

            override fun onResponse(call: Call, response: Response) {
                response.use { resp ->
                    val raw = resp.body?.string().orEmpty()
                    if (!resp.isSuccessful) {
                        onResult("❗ 接口错误 ${resp.code}：${raw.take(160)}")
                        return
                    }
                    try {
                        onResult(JSONObject(raw).getJSONArray("choices").getJSONObject(0)
                            .getJSONObject("message").getString("content").trim())
                    } catch (e: Exception) {
                        onResult("❗ 解析失败：" + raw.take(160))
                    }
                }
            }
        })
    }
}
