package com.rorykosanke.fanyifloat

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** 翻译记录页：按 日期 → 时间段(同一段连续观看) 自动分类展示。 */
class HistoryActivity : Activity() {

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(20), dp(16), dp(24))
        root.setBackgroundColor(0xFF0B1220.toInt())

        val title = TextView(this)
        title.text = "翻译记录"
        title.setTextColor(0xFFFFFFFF.toInt())
        title.textSize = 22f
        title.setTypeface(null, android.graphics.Typeface.BOLD)
        root.addView(title)

        val sub = TextView(this)
        sub.text = "自动按 日期 和 同一段观看(时间相邻) 分类"
        sub.setTextColor(0xFF8EA1BD.toInt())
        sub.textSize = 12f
        sub.setPadding(0, dp(4), 0, dp(12))
        root.addView(sub)

        val recs = RecordStore.load(this)

        if (recs.isEmpty()) {
            val empty = TextView(this)
            empty.text = "还没有记录。\n开启悬浮翻译翻几条后，这里会自动出现。"
            empty.setTextColor(0xFF56657D.toInt())
            empty.textSize = 14f
            empty.setPadding(0, dp(30), 0, 0)
            root.addView(empty)
        } else {
            // 按日期分组，再按时间段分段
            val dayFmt = SimpleDateFormat("yyyy年M月d日 EEEE", Locale.CHINA)
            val hmFmt = SimpleDateFormat("HH:mm", Locale.CHINA)

            var i = 0
            val n = recs.size
            while (i < n) {
                // 收集同一天
                val dayStart = recs[i].ts
                val dayEndRef = Date(dayStart)
                val dayList = ArrayList<RecordStore.Rec>()
                while (i < n) {
                    val s1 = dayFmt.format(Date(recs[i].ts))
                    val s0 = dayFmt.format(dayEndRef)
                    if (s1 != s0) break
                    dayList.add(recs[i]); i++
                }

                // 日期标题
                val dayHeader = TextView(this)
                dayHeader.text = dayFmt.format(Date(dayStart))
                dayHeader.setTextColor(0xFF22C55E.toInt())
                dayHeader.textSize = 14f
                dayHeader.setTypeface(null, android.graphics.Typeface.BOLD)
                dayHeader.setPadding(0, dp(14), 0, dp(6))
                root.addView(dayHeader)

                // 一天内按时间间隔(>2分钟)切成多段
                var j = 0
                while (j < dayList.size) {
                    val seg = ArrayList<RecordStore.Rec>()
                    seg.add(dayList[j])
                    var k = j + 1
                    while (k < dayList.size && dayList[k].ts - dayList[k - 1].ts <= 120_000L) {
                        seg.add(dayList[k]); k++
                    }
                    val startT = hmFmt.format(Date(seg.first().ts))
                    val endT = hmFmt.format(Date(seg.last().ts))
                    addSegmentCard(root, "$startT - $endT（${seg.size}句）", seg)
                    j = k
                }
            }
        }

        val clearBtn = Button(this)
        clearBtn.text = "清空全部记录"
        clearBtn.isAllCaps = false
        clearBtn.setTextColor(0xFFFFFFFF.toInt())
        clearBtn.background = GradientDrawable().apply {
            setColor(0xFFB91C1C.toInt()); cornerRadius = dp(12).toFloat()
        }
        val clp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        clp.topMargin = dp(20)
        clearBtn.layoutParams = clp
        clearBtn.stateListAnimator = null
        clearBtn.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("确认清空？")
                .setMessage("将删除全部翻译记录，无法恢复。")
                .setPositiveButton("清空") { _, _ ->
                    RecordStore.clear(this)
                    Toast.makeText(this, "已清空", Toast.LENGTH_SHORT).show()
                    buildUi()
                }
                .setNegativeButton("取消", null)
                .show()
        }
        root.addView(clearBtn)

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun addSegmentCard(parent: LinearLayout, timeLabel: String, seg: List<RecordStore.Rec>) {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(12), dp(10), dp(12), dp(10))
        card.background = GradientDrawable().apply {
            setColor(0xFF111A2B.toInt()); cornerRadius = dp(12).toFloat()
        }
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.bottomMargin = dp(10)
        card.layoutParams = lp

        val tl = TextView(this)
        tl.text = "🕘 " + timeLabel
        tl.setTextColor(0xFF0EA5E9.toInt())
        tl.textSize = 12f
        tl.setPadding(0, 0, 0, dp(6))
        card.addView(tl)

        for (r in seg) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)

            val orig = TextView(this)
            orig.text = r.original
            orig.setTextColor(0xFF7C8DA6.toInt())
            orig.textSize = 12f
            orig.setPadding(0, dp(2), 0, 0)
            orig.setTextIsSelectable(true)
            col.addView(orig)

            val tr = TextView(this)
            tr.text = "→ " + r.translated
            tr.setTextColor(0xFFFFFFFF.toInt())
            tr.textSize = 15f
            tr.setPadding(0, dp(1), 0, dp(6))
            tr.setTextIsSelectable(true)
            col.addView(tr)
            row.addView(col)

            val copy = TextView(this)
            copy.text = "复制"
            copy.setTextColor(0xFF22C55E.toInt())
            copy.textSize = 12f
            copy.setPadding(dp(8), dp(6), dp(2), dp(2))
            copy.isClickable = true
            copy.setOnClickListener {
                try {
                    val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("翻译", r.original + "\n" + r.translated))
                    Toast.makeText(this, "已复制这条", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                }
            }
            row.addView(copy)
            card.addView(row)
        }
        parent.addView(card)
    }
}
