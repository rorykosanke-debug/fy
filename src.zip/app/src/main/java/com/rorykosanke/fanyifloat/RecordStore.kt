package com.rorykosanke.fanyifloat

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** 翻译记录存储：保存在 App 内部文件 history.json，最多 500 条。 */
object RecordStore {

    private const val FILE = "history.json"
    private const val MAX = 500

    data class Rec(val ts: Long, val original: String, val translated: String)

    @Synchronized
    fun add(ctx: Context, original: String, translated: String) {
        if (translated.isBlank() || translated.startsWith("❗")) return
        if (original.isBlank()) return
        val list = load(ctx).toMutableList()
        val last = list.lastOrNull()
        if (last != null && last.original == original && last.translated == translated) return
        list.add(Rec(System.currentTimeMillis(), original.trim(), translated.trim()))
        while (list.size > MAX) list.removeAt(0)
        save(ctx, list)
    }

    fun load(ctx: Context): List<Rec> {
        val out = ArrayList<Rec>()
        try {
            val f = File(ctx.filesDir, FILE)
            if (!f.exists()) return out
            val arr = JSONArray(f.readText())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Rec(o.optLong("t"), o.optString("o"), o.optString("r")))
            }
        } catch (e: Exception) {
        }
        return out
    }

    private fun save(ctx: Context, list: List<Rec>) {
        try {
            val arr = JSONArray()
            for (r in list) {
                arr.put(JSONObject().put("t", r.ts).put("o", r.original).put("r", r.translated))
            }
            File(ctx.filesDir, FILE).writeText(arr.toString())
        } catch (e: Exception) {
        }
    }

    fun clear(ctx: Context) {
        try {
            File(ctx.filesDir, FILE).delete()
        } catch (e: Exception) {
        }
    }
}
